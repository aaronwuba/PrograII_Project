package app;

import DAO.ServicioDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import models.Servicio;

public class Principal {
    // Cambiar estos datos según la base de datos de tu computadora.
    private static final String URL = "jdbc:mysql://localhost:3306/taller_mecanico";
    private static final String USUARIO = "root";
    private static final String CLAVE = "";

    public static void main(String[] args) {
        try (Connection conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);
             Scanner teclado = new Scanner(System.in)) {

            ServicioDAO dao = new ServicioDAO(conexion);
            int opcion;
            do {
                System.out.println("\n--- CATÁLOGO DE SERVICIOS ---");
                System.out.println("1. Registrar servicio");
                System.out.println("2. Consultar servicios");
                System.out.println("3. Modificar servicio");
                System.out.println("4. Eliminar servicio");
                System.out.println("5. Salir");
                opcion = leerEntero(teclado, "Seleccione una opción: ");

                try {
                    switch (opcion) {
                        case 1:
                            String nombre = leerTexto(teclado, "Nombre: ");
                            String descripcion = leerTexto(teclado, "Descripción: ");
                            double precio = leerPrecio(teclado);
                            Servicio nuevo = new Servicio(0, nombre, descripcion, precio);
                            System.out.println(dao.registrar(nuevo) ? "Servicio registrado." : "No se registró.");
                            break;
                        case 2:
                            ArrayList<Servicio> servicios = dao.consultar();
                            if (servicios.isEmpty()) {
                                System.out.println("Todavía no hay servicios registrados.");
                            }
                            for (Servicio s : servicios) {
                                System.out.println(s);
                            }
                            break;
                        case 3:
                            int idModificar = leerEntero(teclado, "ID a modificar: ");
                            String nuevoNombre = leerTexto(teclado, "Nuevo nombre: ");
                            String nuevaDescripcion = leerTexto(teclado, "Nueva descripción: ");
                            double nuevoPrecio = leerPrecio(teclado);
                            Servicio modificado = new Servicio(idModificar, nuevoNombre, nuevaDescripcion, nuevoPrecio);
                            System.out.println(dao.modificar(modificado) ? "Servicio modificado." : "No se encontró ese ID.");
                            break;
                        case 4:
                            int idEliminar = leerEntero(teclado, "ID a eliminar: ");
                            System.out.println(dao.eliminar(idEliminar) ? "Servicio eliminado." : "No se encontró ese ID.");
                            break;
                        case 5:
                            System.out.println("Hasta luego.");
                            break;
                        default:
                            System.out.println("Opción incorrecta.");
                    }
                } catch (SQLException e) {
                    System.out.println("Error de base de datos: " + e.getMessage());
                }
            } while (opcion != 5);
        } catch (SQLException e) {
            System.out.println("No se pudo conectar con la base de datos.");
            System.out.println("Revise MySQL, el nombre de la base y los datos de conexión.");
            System.out.println("Detalle: " + e.getMessage());
        }
    }

    private static int leerEntero(Scanner teclado, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Escriba un número entero.");
            }
        }
    }

    private static String leerTexto(Scanner teclado, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("Este dato no puede quedar vacío.");
        }
    }

    private static double leerPrecio(Scanner teclado) {
        while (true) {
            System.out.print("Precio: ");
            try {
                double precio = Double.parseDouble(teclado.nextLine().trim().replace(',', '.'));
                if (precio >= 0 && Double.isFinite(precio)) {
                    return precio;
                }
            } catch (NumberFormatException e) {
                // Se muestra el mensaje de abajo.
            }
            System.out.println("Escriba un precio válido (cero o mayor).");
        }
    }
}
